# Replit.md

## Overview

This is a badminton booking application that allows group members to schedule and manage court slots. The application provides a calendar-based interface for booking weekday slots (8:30 AM - 9:45 AM) with a maximum of 6 slots available per day. It features member selection, booking management, activity tracking, and monthly participation statistics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, built using Vite
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens inspired by Ramp's design system
- **Form Handling**: React Hook Form with Zod validation resolvers

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful API with routes for bookings, activities, and statistics
- **Data Storage**: In-memory storage implementation with interface for future database integration
- **Error Handling**: Centralized error middleware with structured error responses
- **Development**: Hot reloading with Vite integration for full-stack development

### Data Models
- **Bookings**: Core entity with date, member name, device info, and timestamps
- **Activities**: Audit trail for booking and cancellation actions
- **Members**: Predefined list of group members for validation
- **Monthly Stats**: Aggregated participation data by member and month

### Database Schema
- **Database**: PostgreSQL (configured but using in-memory storage currently)
- **ORM**: Drizzle ORM with type-safe queries and migrations
- **Connection**: Neon Database serverless connection
- **Validation**: Drizzle-Zod integration for runtime schema validation

### Key Features
- **Calendar Interface**: Weekday-only booking with 2-week lookahead
- **Member Management**: Dropdown selection with predefined member list
- **Slot Validation**: Prevents double-booking and enforces 6-slot daily limit
- **Activity Tracking**: Real-time activity feed with booking/cancellation history
- **Participation Analytics**: Monthly statistics with visual participation rates
- **Device Detection**: Tracks booking source (iPhone, Android, Desktop)

### Authentication & Authorization
- **Current State**: No authentication implemented
- **Session Management**: Basic session handling prepared with connect-pg-simple
- **Member Validation**: Server-side validation against predefined member list

## External Dependencies

### Core Framework Dependencies
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight React router
- **react-hook-form**: Form state management
- **@hookform/resolvers**: Form validation integration

### Database & ORM
- **drizzle-orm**: Type-safe PostgreSQL ORM
- **drizzle-kit**: Database migration and schema management tools
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **connect-pg-simple**: PostgreSQL session store for Express

### UI & Styling
- **@radix-ui/***: Headless UI primitives (30+ components)
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **clsx**: Conditional className utility
- **lucide-react**: Icon library

### Development Tools
- **vite**: Build tool and development server
- **typescript**: Type checking and compilation
- **esbuild**: Fast JavaScript bundler for production
- **tsx**: TypeScript execution for development

### Date & Time
- **date-fns**: Date manipulation and formatting library

### Validation
- **zod**: TypeScript-first schema validation
- **drizzle-zod**: Integration between Drizzle ORM and Zod

### Additional UI Components
- **embla-carousel-react**: Carousel component for enhanced UX
- **cmdk**: Command palette component for search interfaces