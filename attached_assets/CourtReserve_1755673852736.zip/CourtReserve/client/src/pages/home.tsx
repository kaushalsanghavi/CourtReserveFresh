import { useState } from "react";
import { BookingCalendar } from "@/components/booking-calendar";
import { MemberSelector } from "@/components/member-selector";
import { RecentActivity } from "@/components/recent-activity";
import { MonthlyParticipation } from "@/components/monthly-participation";

export default function Home() {
  const [selectedMember, setSelectedMember] = useState("");
  const [activeTab, setActiveTab] = useState("recent");

  const handleQuickBook = () => {
    // This would implement bulk booking functionality
    // For now, just show the calendar with selected member
  };

  return (
    <div className="min-h-screen bg-ramp-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-ramp-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-semibold text-ramp-gray-900">
                Our own Slot bookings for Badminton
              </h1>
              <span className="ml-3 px-2 py-1 text-xs font-medium bg-ramp-gray-100 text-ramp-gray-600 rounded">
                Group Scheduler @ Sunny
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-ramp-gray-500">
                8:30 AM - 9:45 AM
              </span>
              <span className="text-sm text-ramp-gray-500">•</span>
              <span className="text-sm text-ramp-gray-500">
                6 slots available daily
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Top Navigation */}
        <div className="mb-8">
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab("recent")}
              className={`border-b-2 pb-4 text-sm font-medium ${
                activeTab === "recent"
                  ? "text-ramp-gray-900 border-ramp-green-500"
                  : "text-ramp-gray-500 border-transparent hover:text-ramp-gray-700"
              }`}
              data-testid="tab-recent-activity"
            >
              Recent Activity
            </button>
            <button
              onClick={() => setActiveTab("monthly")}
              className={`border-b-2 pb-4 text-sm font-medium ${
                activeTab === "monthly"
                  ? "text-ramp-gray-900 border-ramp-green-500"
                  : "text-ramp-gray-500 border-transparent hover:text-ramp-gray-700"
              }`}
              data-testid="tab-monthly-participation"
            >
              Monthly Participation
            </button>
          </nav>
        </div>

        {/* Member Selector */}
        <MemberSelector
          selectedMember={selectedMember}
          onMemberSelect={setSelectedMember}
          onQuickBook={handleQuickBook}
        />

        {/* Booking Calendar */}
        <BookingCalendar selectedMember={selectedMember} />

        {/* Content based on active tab */}
        {activeTab === "recent" ? <RecentActivity /> : <MonthlyParticipation />}
      </div>
    </div>
  );
}
