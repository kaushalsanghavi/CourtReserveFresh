import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import type { Activity } from "@shared/schema";

export function RecentActivity() {
  const { data: activities = [], isLoading } = useQuery<Activity[]>({
    queryKey: ['/api/activities'],
  });

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-ramp-gray-200 mb-8">
        <div className="p-6 border-b border-ramp-gray-200">
          <h2 className="text-lg font-medium text-ramp-gray-900">Recent Activity</h2>
          <p className="text-sm text-ramp-gray-500 mt-1">Latest bookings and cancellations</p>
        </div>
        <div className="divide-y divide-ramp-gray-200">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="p-6 animate-pulse">
              <div className="flex items-center space-x-4">
                <div className="w-8 h-8 bg-ramp-gray-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-ramp-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-ramp-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-ramp-gray-200 mb-8">
      <div className="p-6 border-b border-ramp-gray-200">
        <h2 className="text-lg font-medium text-ramp-gray-900">Recent Activity</h2>
        <p className="text-sm text-ramp-gray-500 mt-1">Latest bookings and cancellations</p>
      </div>
      <div className="divide-y divide-ramp-gray-200">
        {activities.length === 0 ? (
          <div className="p-6 text-center">
            <p className="text-sm text-ramp-gray-500">No recent activity</p>
          </div>
        ) : (
          activities.map((activity) => (
            <div key={activity.id} className="p-6 flex items-center justify-between" data-testid={`activity-${activity.id}`}>
              <div className="flex items-center space-x-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  activity.type === 'book' 
                    ? 'bg-ramp-green-100' 
                    : 'bg-red-100'
                }`}>
                  <div className={`w-2 h-2 rounded-full ${
                    activity.type === 'book' 
                      ? 'bg-ramp-green-500' 
                      : 'bg-red-500'
                  }`} />
                </div>
                <div>
                  <p className="text-sm font-medium text-ramp-gray-900">
                    <span className="text-ramp-gray-700">{activity.memberName}</span>{' '}
                    {activity.type === 'book' ? 'booked a slot for' : 'cancelled slot for'}{' '}
                    <span className="text-ramp-gray-700">{new Date(activity.date).toLocaleDateString('en-US', { 
                      weekday: 'short', 
                      month: 'short', 
                      day: 'numeric' 
                    })}</span>
                  </p>
                  <p className="text-xs text-ramp-gray-500">
                    {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })} • from {activity.deviceInfo || 'Unknown device'}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
