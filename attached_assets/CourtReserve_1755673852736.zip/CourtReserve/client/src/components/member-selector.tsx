import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { MEMBERS } from "@shared/schema";

interface MemberSelectorProps {
  selectedMember: string;
  onMemberSelect: (member: string) => void;
  onQuickBook: () => void;
}

export function MemberSelector({ selectedMember, onMemberSelect, onQuickBook }: MemberSelectorProps) {
  const { toast } = useToast();

  const handleQuickBook = () => {
    if (!selectedMember) {
      toast({
        title: "No member selected",
        description: "Please select a member before quick booking.",
        variant: "destructive",
      });
      return;
    }
    onQuickBook();
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-ramp-gray-200 p-6 mb-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-medium text-ramp-gray-900">Quick Booking</h2>
          <p className="text-sm text-ramp-gray-500 mt-1">Select your name to book or cancel slots</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={selectedMember} onValueChange={onMemberSelect}>
            <SelectTrigger className="w-48" data-testid="select-member">
              <SelectValue placeholder="Select member..." />
            </SelectTrigger>
            <SelectContent>
              {MEMBERS.map((member) => (
                <SelectItem key={member} value={member}>
                  {member}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button 
            onClick={handleQuickBook}
            className="bg-ramp-green-500 hover:bg-ramp-green-600 text-white"
            data-testid="button-quick-book"
          >
            Quick Book
          </Button>
        </div>
      </div>
    </div>
  );
}
