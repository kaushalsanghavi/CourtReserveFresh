import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { getWeekdaysInRange, formatDateForAPI, formatDateForDisplay, getDateLabel, getDeviceInfo } from "@/lib/date-utils";
import { startOfToday, startOfWeek, format, addWeeks } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import type { Booking } from "@shared/schema";

interface BookingCalendarProps {
  selectedMember: string;
}

export function BookingCalendar({ selectedMember }: BookingCalendarProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const weekdays = getWeekdaysInRange(startOfToday(), 10); // 2 weeks of weekdays

  // Group weekdays by week for better visual organization
  const groupWeekdaysByWeek = (dates: Date[]) => {
    const weeks: { weekStart: Date; weekLabel: string; days: Date[] }[] = [];
    
    dates.forEach(date => {
      const weekStart = startOfWeek(date, { weekStartsOn: 1 }); // Monday start
      const weekLabel = format(weekStart, 'MMM d') + ' - ' + format(addWeeks(weekStart, 0), 'MMM d');
      
      let existingWeek = weeks.find(week => 
        week.weekStart.getTime() === weekStart.getTime()
      );
      
      if (!existingWeek) {
        existingWeek = {
          weekStart,
          weekLabel: `Week of ${format(weekStart, 'MMM d')}`,
          days: []
        };
        weeks.push(existingWeek);
      }
      
      existingWeek.days.push(date);
    });
    
    return weeks;
  };

  const weeklyGroups = groupWeekdaysByWeek(weekdays);

  const { data: bookings = [], isLoading } = useQuery<Booking[]>({
    queryKey: ['/api/bookings'],
  });

  const bookMutation = useMutation({
    mutationFn: async ({ date, memberName }: { date: string; memberName: string }) => {
      return await apiRequest('POST', '/api/bookings', {
        date,
        memberName,
        deviceInfo: getDeviceInfo(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: "Booking successful",
        description: "Your slot has been booked.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Booking failed",
        description: error.message || "Unable to book slot.",
        variant: "destructive",
      });
    },
  });

  const cancelMutation = useMutation({
    mutationFn: async ({ date, memberName }: { date: string; memberName: string }) => {
      return await apiRequest('DELETE', `/api/bookings/${date}/${encodeURIComponent(memberName)}`, {
        deviceInfo: getDeviceInfo(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: "Booking cancelled",
        description: "Your slot has been cancelled.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Cancellation failed",
        description: error.message || "Unable to cancel booking.",
        variant: "destructive",
      });
    },
  });

  const getBookingsForDate = (date: string) => {
    return bookings.filter(booking => booking.date === date);
  };

  const isMemberBooked = (date: string, memberName: string) => {
    return bookings.some(booking => booking.date === date && booking.memberName === memberName);
  };

  const handleSlotAction = (date: string) => {
    if (!selectedMember) {
      toast({
        title: "No member selected",
        description: "Please select a member first.",
        variant: "destructive",
      });
      return;
    }

    const isBooked = isMemberBooked(date, selectedMember);
    
    if (isBooked) {
      cancelMutation.mutate({ date, memberName: selectedMember });
    } else {
      bookMutation.mutate({ date, memberName: selectedMember });
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-ramp-gray-200 mb-8">
        <div className="p-6 border-b border-ramp-gray-200">
          <h2 className="text-lg font-medium text-ramp-gray-900">2-Week Booking Window</h2>
          <p className="text-sm text-ramp-gray-500 mt-1">Weekdays only (Monday - Friday)</p>
        </div>
        <div className="p-6 space-y-8">
          {Array.from({ length: 2 }).map((_, weekIndex) => (
            <div key={weekIndex}>
              <div className="flex items-center mb-4">
                <div className="h-px bg-ramp-gray-200 flex-1"></div>
                <div className="px-4 text-sm font-medium text-ramp-gray-600 animate-pulse">
                  <div className="h-4 bg-ramp-gray-200 rounded w-24"></div>
                </div>
                <div className="h-px bg-ramp-gray-200 flex-1"></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                {Array.from({ length: 5 }).map((_, dayIndex) => (
                  <div key={dayIndex} className="border border-ramp-gray-200 rounded-lg p-4 animate-pulse">
                    <div className="h-4 bg-ramp-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-ramp-gray-200 rounded mb-4"></div>
                    <div className="h-8 bg-ramp-gray-200 rounded"></div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-ramp-gray-200 mb-8">
      <div className="p-6 border-b border-ramp-gray-200">
        <h2 className="text-lg font-medium text-ramp-gray-900">2-Week Booking Window</h2>
        <p className="text-sm text-ramp-gray-500 mt-1">Weekdays only (Monday - Friday)</p>
      </div>
      <div className="p-6 space-y-8">
        {weeklyGroups.map((week, weekIndex) => (
          <div key={week.weekStart.getTime()}>
            {/* Week Header */}
            <div className="flex items-center mb-6">
              <div className="h-px bg-ramp-gray-200 flex-1"></div>
              <div className="px-4 text-sm font-medium text-ramp-gray-600">
                {week.weekLabel}
              </div>
              <div className="h-px bg-ramp-gray-200 flex-1"></div>
            </div>
            
            {/* Days Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              {week.days.map((date) => {
                const dateStr = formatDateForAPI(date);
                const dayBookings = getBookingsForDate(dateStr);
                const slotsUsed = dayBookings.length;
                const maxSlots = 6;
                const isFullyBooked = slotsUsed >= maxSlots;
                const isMemberBookedForDate = selectedMember ? isMemberBooked(dateStr, selectedMember) : false;

                return (
                  <div key={dateStr} className="border border-ramp-gray-200 rounded-lg p-4 hover:border-ramp-gray-300 transition-colors">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="font-medium text-ramp-gray-900">
                          {formatDateForDisplay(date)}
                        </h3>
                        <p className="text-sm text-ramp-gray-500">
                          {getDateLabel(date)}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-ramp-gray-600">
                          {slotsUsed}/{maxSlots}
                        </span>
                        <div 
                          className={`w-2 h-2 rounded-full ${
                            isFullyBooked ? 'bg-red-500' : 'bg-ramp-green-500'
                          }`}
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2 mb-4">
                      <p className="text-xs font-medium text-ramp-gray-500 uppercase tracking-wide">
                        Booked Members
                      </p>
                      <div className="flex flex-wrap gap-1 min-h-[1.5rem]">
                        {dayBookings.length > 0 ? (
                          dayBookings.map((booking) => (
                            <span 
                              key={booking.id}
                              className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-ramp-gray-100 text-ramp-gray-700"
                            >
                              {booking.memberName}
                            </span>
                          ))
                        ) : (
                          <span className="text-sm text-ramp-gray-400 italic">
                            No bookings yet
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <Button
                      className={`w-full ${
                        isMemberBookedForDate
                          ? 'bg-red-50 text-red-700 border border-red-200 hover:bg-red-100'
                          : isFullyBooked
                          ? 'bg-ramp-gray-100 text-ramp-gray-500 border border-ramp-gray-200 cursor-not-allowed'
                          : 'bg-ramp-green-50 text-ramp-green-700 border border-ramp-green-200 hover:bg-ramp-green-100'
                      }`}
                      onClick={() => handleSlotAction(dateStr)}
                      disabled={isFullyBooked && !isMemberBookedForDate || bookMutation.isPending || cancelMutation.isPending}
                      variant="outline"
                      data-testid={`button-slot-${dateStr}`}
                    >
                      {isMemberBookedForDate 
                        ? 'Cancel Booking' 
                        : isFullyBooked 
                        ? 'Fully Booked' 
                        : 'Book Slot'
                      }
                    </Button>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
