import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MEMBERS } from "@shared/schema";

export function MonthlyParticipation() {
  const currentDate = new Date();
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);

  const { data: stats = {}, isLoading } = useQuery<{ [memberName: string]: number }>({
    queryKey: ['/api/stats/monthly', selectedYear, selectedMonth],
  });

  const months = [
    { value: 1, label: "January" },
    { value: 2, label: "February" },
    { value: 3, label: "March" },
    { value: 4, label: "April" },
    { value: 5, label: "May" },
    { value: 6, label: "June" },
    { value: 7, label: "July" },
    { value: 8, label: "August" },
    { value: 9, label: "September" },
    { value: 10, label: "October" },
    { value: 11, label: "November" },
    { value: 12, label: "December" },
  ];

  const years = [2024, 2025, 2026];

  const getParticipationRate = (bookings: number) => {
    // Assume ~22 working days per month
    const workingDays = 22;
    return Math.round((bookings / workingDays) * 100);
  };

  const getStatusColor = (rate: number) => {
    if (rate >= 70) return "bg-ramp-green-100 text-ramp-green-800";
    if (rate >= 40) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const getStatusLabel = (rate: number) => {
    if (rate >= 70) return "Active";
    if (rate >= 40) return "Moderate";
    return "Low";
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(word => word[0]).join('').slice(0, 2).toUpperCase();
  };

  const getAvatarColor = (index: number) => {
    const colors = [
      'bg-ramp-green-100 text-ramp-green-700',
      'bg-blue-100 text-blue-700',
      'bg-purple-100 text-purple-700',
      'bg-indigo-100 text-indigo-700',
      'bg-pink-100 text-pink-700',
      'bg-orange-100 text-orange-700',
      'bg-cyan-100 text-cyan-700',
      'bg-emerald-100 text-emerald-700',
      'bg-violet-100 text-violet-700',
      'bg-amber-100 text-amber-700',
      'bg-teal-100 text-teal-700'
    ];
    return colors[index % colors.length];
  };

  return (
    <div id="monthly" className="bg-white rounded-lg shadow-sm border border-ramp-gray-200">
      <div className="p-6 border-b border-ramp-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-medium text-ramp-gray-900">Monthly Participation</h2>
            <p className="text-sm text-ramp-gray-500 mt-1">
              {months.find(m => m.value === selectedMonth)?.label} {selectedYear} booking statistics
            </p>
          </div>
          <div className="flex space-x-2">
            <Select value={selectedMonth.toString()} onValueChange={(value) => setSelectedMonth(parseInt(value))}>
              <SelectTrigger className="w-32" data-testid="select-month">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {months.map((month) => (
                  <SelectItem key={month.value} value={month.value.toString()}>
                    {month.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
              <SelectTrigger className="w-20" data-testid="select-year">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-ramp-gray-200">
          <thead className="bg-ramp-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-ramp-gray-500 uppercase tracking-wider">
                Member
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-ramp-gray-500 uppercase tracking-wider">
                Total Bookings
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-ramp-gray-500 uppercase tracking-wider">
                Participation Rate
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-ramp-gray-500 uppercase tracking-wider">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-ramp-gray-200">
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i} className="animate-pulse">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-ramp-gray-200 rounded-full"></div>
                      <div className="ml-3 h-4 bg-ramp-gray-200 rounded w-20"></div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="h-4 bg-ramp-gray-200 rounded w-8"></div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="h-4 bg-ramp-gray-200 rounded w-24"></div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="h-4 bg-ramp-gray-200 rounded w-16"></div>
                  </td>
                </tr>
              ))
            ) : (
              MEMBERS.map((member, index) => {
                const bookings = stats[member] || 0;
                const participationRate = getParticipationRate(bookings);
                const statusColor = getStatusColor(participationRate);
                const statusLabel = getStatusLabel(participationRate);

                return (
                  <tr key={member} className="hover:bg-ramp-gray-50" data-testid={`member-row-${member}`}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getAvatarColor(index)}`}>
                          <span className="text-xs font-medium">
                            {getInitials(member)}
                          </span>
                        </div>
                        <div className="ml-3">
                          <div className="text-sm font-medium text-ramp-gray-900">
                            {member}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-ramp-gray-900">
                      {bookings}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-1 bg-ramp-gray-200 rounded-full h-2 mr-2">
                          <div 
                            className="bg-ramp-green-500 h-2 rounded-full" 
                            style={{ width: `${Math.min(participationRate, 100)}%` }}
                          />
                        </div>
                        <span className="text-sm text-ramp-gray-600">
                          {participationRate}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColor}`}>
                        {statusLabel}
                      </span>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
