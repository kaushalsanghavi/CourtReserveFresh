import { format, addDays, isWeekend, startOfToday } from "date-fns";

export function getWeekdaysInRange(startDate: Date, days: number): Date[] {
  const weekdays: Date[] = [];
  let currentDate = startDate;
  let addedDays = 0;

  while (addedDays < days) {
    if (!isWeekend(currentDate)) {
      weekdays.push(new Date(currentDate));
      addedDays++;
    }
    currentDate = addDays(currentDate, 1);
  }

  return weekdays;
}

export function formatDateForAPI(date: Date): string {
  return format(date, "yyyy-MM-dd");
}

export function formatDateForDisplay(date: Date): string {
  return format(date, "EEE, MMM d");
}

export function getDateLabel(date: Date): string {
  const today = startOfToday();
  const tomorrow = addDays(today, 1);
  
  if (format(date, "yyyy-MM-dd") === format(today, "yyyy-MM-dd")) {
    return "Today";
  } else if (format(date, "yyyy-MM-dd") === format(tomorrow, "yyyy-MM-dd")) {
    return "Tomorrow";
  } else {
    return format(date, "EEEE");
  }
}

export function getDeviceInfo(): string {
  const userAgent = navigator.userAgent;
  
  // iPhone detection with specific model identification
  if (/iPhone/.test(userAgent)) {
    const iOSMatch = userAgent.match(/iPhone\s?OS\s?(\d+)_(\d+)/);
    const version = iOSMatch ? `${iOSMatch[1]}.${iOSMatch[2]}` : '';
    
    // Enhanced iPhone model detection using multiple patterns
    if (userAgent.includes('iPhone17,') || userAgent.includes('iPhone16,5') || userAgent.includes('iPhone16,4')) {
      return `iPhone 16 Pro${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone16,2') || userAgent.includes('iPhone16,1')) {
      return `iPhone 16${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone15,5') || userAgent.includes('iPhone15,4')) {
      return `iPhone 15 Pro Max${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone15,3') || userAgent.includes('iPhone15,2')) {
      return `iPhone 15 Pro${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone14,8') || userAgent.includes('iPhone14,7')) {
      return `iPhone 14 Plus${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone14,3') || userAgent.includes('iPhone14,2')) {
      return `iPhone 13 Pro Max${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone13,4') || userAgent.includes('iPhone13,3')) {
      return `iPhone 12 Pro Max${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone13,2') || userAgent.includes('iPhone13,1')) {
      return `iPhone 12 Pro${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone12,8')) {
      return `iPhone SE 2nd Gen${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone12,5') || userAgent.includes('iPhone12,3')) {
      return `iPhone 11 Pro Max${version ? ` (iOS ${version})` : ''}`;
    } else if (userAgent.includes('iPhone12,1')) {
      return `iPhone 11${version ? ` (iOS ${version})` : ''}`;
    }
    return `iPhone${version ? ` (iOS ${version})` : ''}`;
  }
  
  // iPad detection with model specifics
  if (/iPad/.test(userAgent)) {
    const iOSMatch = userAgent.match(/OS\s?(\d+)_(\d+)/);
    const version = iOSMatch ? `${iOSMatch[1]}.${iOSMatch[2]}` : '';
    
    if (userAgent.includes('iPad14,') || userAgent.includes('iPad13,')) {
      return `iPad Pro 12.9"${version ? ` (iPadOS ${version})` : ''}`;
    } else if (userAgent.includes('iPad8,') || userAgent.includes('iPad7,')) {
      return `iPad Pro 11"${version ? ` (iPadOS ${version})` : ''}`;
    } else if (userAgent.includes('iPad11,') || userAgent.includes('iPad12,')) {
      return `iPad Air${version ? ` (iPadOS ${version})` : ''}`;
    }
    return `iPad${version ? ` (iPadOS ${version})` : ''}`;
  }
  
  // Enhanced Android device detection
  if (/Android/.test(userAgent)) {
    const androidMatch = userAgent.match(/Android\s?(\d+\.?\d*)/);
    const androidVersion = androidMatch ? androidMatch[1] : '';
    
    // Samsung Galaxy series with specific model detection
    if (userAgent.includes('SM-S')) {
      // Galaxy S24 series
      if (userAgent.includes('SM-S928') || userAgent.includes('SM-S926') || userAgent.includes('SM-S921')) {
        const model = userAgent.includes('SM-S928') ? 'S24 Ultra' : userAgent.includes('SM-S926') ? 'S24+' : 'S24';
        return `Samsung Galaxy ${model}${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      }
      // Galaxy S23 series
      if (userAgent.includes('SM-S918') || userAgent.includes('SM-S916') || userAgent.includes('SM-S911')) {
        const model = userAgent.includes('SM-S918') ? 'S23 Ultra' : userAgent.includes('SM-S916') ? 'S23+' : 'S23';
        return `Samsung Galaxy ${model}${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      }
    } else if (userAgent.includes('SM-G')) {
      // Galaxy S22 series
      if (userAgent.includes('SM-G998') || userAgent.includes('SM-G996') || userAgent.includes('SM-G991')) {
        const model = userAgent.includes('SM-G998') ? 'S21 Ultra' : userAgent.includes('SM-G996') ? 'S21+' : 'S21';
        return `Samsung Galaxy ${model}${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      }
      // Galaxy S20 series
      if (userAgent.includes('SM-G988') || userAgent.includes('SM-G986') || userAgent.includes('SM-G981')) {
        const model = userAgent.includes('SM-G988') ? 'S20 Ultra' : userAgent.includes('SM-G986') ? 'S20+' : 'S20';
        return `Samsung Galaxy ${model}${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      }
    }
    
    // Google Pixel devices
    if (userAgent.includes('Pixel')) {
      if (userAgent.includes('Pixel 9')) {
        if (userAgent.includes('Pixel 9 Pro')) return `Google Pixel 9 Pro${androidVersion ? ` (Android ${androidVersion})` : ''}`;
        return `Google Pixel 9${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      } else if (userAgent.includes('Pixel 8')) {
        if (userAgent.includes('Pixel 8 Pro')) return `Google Pixel 8 Pro${androidVersion ? ` (Android ${androidVersion})` : ''}`;
        return `Google Pixel 8${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      } else if (userAgent.includes('Pixel 7')) {
        if (userAgent.includes('Pixel 7 Pro')) return `Google Pixel 7 Pro${androidVersion ? ` (Android ${androidVersion})` : ''}`;
        return `Google Pixel 7${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      } else if (userAgent.includes('Pixel 6')) {
        if (userAgent.includes('Pixel 6 Pro')) return `Google Pixel 6 Pro${androidVersion ? ` (Android ${androidVersion})` : ''}`;
        return `Google Pixel 6${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      }
      return `Google Pixel${androidVersion ? ` (Android ${androidVersion})` : ''}`;
    }
    
    // OnePlus devices
    if (userAgent.includes('OnePlus') || userAgent.includes('ONEPLUS')) {
      if (userAgent.includes('OnePlus13') || userAgent.includes('ONEPLUS13')) {
        return `OnePlus 13${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      } else if (userAgent.includes('OnePlus12') || userAgent.includes('ONEPLUS12')) {
        return `OnePlus 12${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      } else if (userAgent.includes('OnePlus11') || userAgent.includes('ONEPLUS11')) {
        return `OnePlus 11${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      } else if (userAgent.includes('OnePlus10') || userAgent.includes('ONEPLUS10')) {
        return `OnePlus 10 Pro${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      }
      return `OnePlus${androidVersion ? ` (Android ${androidVersion})` : ''}`;
    }
    
    // Xiaomi devices
    if (userAgent.includes('Xiaomi') || userAgent.includes('MI ') || userAgent.includes('Redmi')) {
      if (userAgent.includes('Mi 14')) return `Xiaomi Mi 14${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      if (userAgent.includes('Mi 13')) return `Xiaomi Mi 13${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      if (userAgent.includes('Redmi Note')) return `Xiaomi Redmi Note${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      return `Xiaomi${androidVersion ? ` (Android ${androidVersion})` : ''}`;
    }
    
    // Huawei devices
    if (userAgent.includes('HUAWEI') || userAgent.includes('Mate') || userAgent.includes('P60') || userAgent.includes('P50')) {
      if (userAgent.includes('Mate 60')) return `Huawei Mate 60 Pro${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      if (userAgent.includes('P60')) return `Huawei P60 Pro${androidVersion ? ` (Android ${androidVersion})` : ''}`;
      return `Huawei${androidVersion ? ` (Android ${androidVersion})` : ''}`;
    }
    
    return `Android Device${androidVersion ? ` (Android ${androidVersion})` : ''}`;
  }
  
  // Enhanced desktop detection
  if (/Macintosh|Mac OS X/.test(userAgent)) {
    const macMatch = userAgent.match(/Mac OS X\s?(\d+)[._](\d+)[._]?(\d+)?/);
    const macVersion = macMatch ? `${macMatch[1]}.${macMatch[2]}${macMatch[3] ? '.' + macMatch[3] : ''}` : '';
    
    // Detect Mac model hints
    let macModel = 'Mac';
    if (userAgent.includes('Intel')) macModel = 'Intel Mac';
    if (userAgent.includes('ARM') || userAgent.includes('Apple')) macModel = 'Apple Silicon Mac';
    
    // Browser detection
    if (/Chrome/.test(userAgent) && !/Edge/.test(userAgent)) {
      const chromeMatch = userAgent.match(/Chrome\/(\d+)/);
      const chromeVersion = chromeMatch ? chromeMatch[1] : '';
      return `${macModel} (Chrome${chromeVersion ? ' ' + chromeVersion : ''})${macVersion ? ' - macOS ' + macVersion : ''}`;
    } else if (/Safari/.test(userAgent) && !/Chrome/.test(userAgent)) {
      return `${macModel} (Safari)${macVersion ? ' - macOS ' + macVersion : ''}`;
    } else if (/Firefox/.test(userAgent)) {
      const firefoxMatch = userAgent.match(/Firefox\/(\d+)/);
      const firefoxVersion = firefoxMatch ? firefoxMatch[1] : '';
      return `${macModel} (Firefox${firefoxVersion ? ' ' + firefoxVersion : ''})${macVersion ? ' - macOS ' + macVersion : ''}`;
    }
    return `${macModel}${macVersion ? ' - macOS ' + macVersion : ''}`;
  }
  
  if (/Windows/.test(userAgent)) {
    let windowsVersion = 'Windows';
    if (userAgent.includes('Windows NT 10.0')) windowsVersion = 'Windows 11/10';
    if (userAgent.includes('Windows NT 6.3')) windowsVersion = 'Windows 8.1';
    if (userAgent.includes('Windows NT 6.2')) windowsVersion = 'Windows 8';
    if (userAgent.includes('Windows NT 6.1')) windowsVersion = 'Windows 7';
    
    // Browser detection
    if (/Chrome/.test(userAgent) && !/Edge/.test(userAgent)) {
      const chromeMatch = userAgent.match(/Chrome\/(\d+)/);
      const chromeVersion = chromeMatch ? chromeMatch[1] : '';
      return `${windowsVersion} (Chrome${chromeVersion ? ' ' + chromeVersion : ''})`;
    } else if (/Edge/.test(userAgent)) {
      const edgeMatch = userAgent.match(/Edg\/(\d+)/);
      const edgeVersion = edgeMatch ? edgeMatch[1] : '';
      return `${windowsVersion} (Edge${edgeVersion ? ' ' + edgeVersion : ''})`;
    } else if (/Firefox/.test(userAgent)) {
      const firefoxMatch = userAgent.match(/Firefox\/(\d+)/);
      const firefoxVersion = firefoxMatch ? firefoxMatch[1] : '';
      return `${windowsVersion} (Firefox${firefoxVersion ? ' ' + firefoxVersion : ''})`;
    }
    return windowsVersion;
  }
  
  if (/Linux/.test(userAgent)) {
    if (/Ubuntu/.test(userAgent)) return 'Ubuntu Linux';
    if (/Chrome/.test(userAgent)) return 'Linux (Chrome)';
    if (/Firefox/.test(userAgent)) return 'Linux (Firefox)';
    return 'Linux';
  }
  
  return 'Unknown Device';
}
