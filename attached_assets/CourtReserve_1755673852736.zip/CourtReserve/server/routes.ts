import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookingSchema, insertActivitySchema, MEMBERS } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all bookings
  app.get("/api/bookings", async (req, res) => {
    try {
      const bookings = await storage.getBookings();
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  // Get bookings by date
  app.get("/api/bookings/date/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const bookings = await storage.getBookingsByDate(date);
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings for date" });
    }
  });

  // Create booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const validatedData = insertBookingSchema.parse(req.body);
      
      // Check if member is valid
      if (!MEMBERS.includes(validatedData.memberName as any)) {
        return res.status(400).json({ message: "Invalid member name" });
      }

      // Check if slot already exists for this member and date
      const existingBookings = await storage.getBookingsByDate(validatedData.date);
      const memberAlreadyBooked = existingBookings.some(b => b.memberName === validatedData.memberName);
      
      if (memberAlreadyBooked) {
        return res.status(400).json({ message: "Member already has a booking for this date" });
      }

      // Check if slots are full (max 6)
      if (existingBookings.length >= 6) {
        return res.status(400).json({ message: "All slots are booked for this date" });
      }

      const booking = await storage.createBooking(validatedData);
      
      // Create activity log
      await storage.createActivity({
        type: "book",
        memberName: validatedData.memberName,
        date: validatedData.date,
        deviceInfo: validatedData.deviceInfo,
      });

      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  // Cancel booking
  app.delete("/api/bookings/:date/:memberName", async (req, res) => {
    try {
      const { date, memberName } = req.params;
      const { deviceInfo } = req.body;
      
      const deleted = await storage.deleteBooking(date, memberName);
      
      if (!deleted) {
        return res.status(404).json({ message: "Booking not found" });
      }

      // Create activity log
      await storage.createActivity({
        type: "cancel",
        memberName,
        date,
        deviceInfo,
      });

      res.json({ message: "Booking cancelled successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to cancel booking" });
    }
  });

  // Get recent activities
  app.get("/api/activities", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const activities = await storage.getRecentActivities(limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Get monthly stats
  app.get("/api/stats/monthly/:year/:month", async (req, res) => {
    try {
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      if (isNaN(year) || isNaN(month) || month < 1 || month > 12) {
        return res.status(400).json({ message: "Invalid year or month" });
      }

      const stats = await storage.getMonthlyStats(year, month);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch monthly stats" });
    }
  });

  // Get members list
  app.get("/api/members", async (req, res) => {
    res.json(MEMBERS);
  });

  // Manual data trimming endpoint (admin use)
  app.post("/api/admin/trim-data", async (req, res) => {
    try {
      const result = await storage.trimOldData();
      const remainingBookings = await storage.getBookings();
      const remainingActivities = await storage.getRecentActivities(10000);
      
      res.json({ 
        message: "Data trimming completed",
        trimmedBookings: result.trimmedBookings,
        trimmedActivities: result.trimmedActivities,
        remainingBookings: remainingBookings.length,
        remainingActivities: remainingActivities.length
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to trim data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
