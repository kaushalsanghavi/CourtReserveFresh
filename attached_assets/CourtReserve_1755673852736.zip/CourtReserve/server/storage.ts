import { type Booking, type InsertBooking, type Activity, type InsertActivity } from "@shared/schema";
import { randomUUID } from "crypto";
import { writeFileSync, readFileSync, existsSync } from "fs";
import { resolve } from "path";

export interface IStorage {
  // Bookings
  getBookings(): Promise<Booking[]>;
  getBookingsByDate(date: string): Promise<Booking[]>;
  getBookingsByMember(memberName: string): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  deleteBooking(date: string, memberName: string): Promise<boolean>;

  // Activities
  getRecentActivities(limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Monthly stats
  getMonthlyStats(year: number, month: number): Promise<{ [memberName: string]: number }>;

  // Data trimming
  trimOldData(): Promise<{ trimmedBookings: number; trimmedActivities: number }>;
}

export class MemStorage implements IStorage {
  private bookings: Map<string, Booking>;
  private activities: Activity[];

  constructor() {
    this.bookings = new Map();
    this.activities = [];
  }

  async getBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }

  async getBookingsByDate(date: string): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(booking => booking.date === date);
  }

  async getBookingsByMember(memberName: string): Promise<Booking[] > {
    return Array.from(this.bookings.values()).filter(booking => booking.memberName === memberName);
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = randomUUID();
    const booking: Booking = {
      ...insertBooking,
      id,
      deviceInfo: insertBooking.deviceInfo ?? null,
      createdAt: new Date(),
    };

    const key = `${booking.date}-${booking.memberName}`;
    this.bookings.set(key, booking);
    return booking;
  }

  async deleteBooking(date: string, memberName: string): Promise<boolean> {
    const key = `${date}-${memberName}`;
    return this.bookings.delete(key);
  }

  async getRecentActivities(limit: number = 20): Promise<Activity[]> {
    return this.activities
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = randomUUID();
    const activity: Activity = {
      ...insertActivity,
      id,
      deviceInfo: insertActivity.deviceInfo ?? null,
      createdAt: new Date(),
    };

    this.activities.push(activity);
    return activity;
  }

  async getMonthlyStats(year: number, month: number): Promise<{ [memberName: string]: number }> {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);

    const monthBookings = Array.from(this.bookings.values()).filter(booking => {
      const bookingDate = new Date(booking.date);
      return bookingDate >= startDate && bookingDate <= endDate;
    });

    const stats: { [memberName: string]: number } = {};
    monthBookings.forEach(booking => {
      stats[booking.memberName] = (stats[booking.memberName] || 0) + 1;
    });

    return stats;
  }

  async trimOldData(): Promise<{ trimmedBookings: number; trimmedActivities: number }> {
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);

    const oldBookingCount = this.bookings.size;
    const oldActivityCount = this.activities.length;

    // Remove old bookings
    for (const [key, booking] of this.bookings.entries()) {
      const bookingDate = new Date(booking.date);
      if (bookingDate < threeMonthsAgo) {
        this.bookings.delete(key);
      }
    }

    // Remove old activities
    this.activities = this.activities.filter(activity => {
      return activity.createdAt >= threeMonthsAgo;
    });

    const trimmedBookings = oldBookingCount - this.bookings.size;
    const trimmedActivities = oldActivityCount - this.activities.length;

    return { trimmedBookings, trimmedActivities };
  }
}

export class FileStorage implements IStorage {
  private dataFile: string;
  private bookings: Map<string, Booking>;
  private activities: Activity[];

  constructor() {
    this.dataFile = resolve(process.cwd(), 'badminton-data.json');
    this.bookings = new Map();
    this.activities = [];
    this.loadData();
  }

  private loadData(): void {
    try {
      if (existsSync(this.dataFile)) {
        const rawData = readFileSync(this.dataFile, 'utf-8');
        const data = JSON.parse(rawData);

        // Load bookings
        if (data.bookings) {
          data.bookings.forEach((booking: any) => {
            booking.createdAt = new Date(booking.createdAt);
            const key = `${booking.date}-${booking.memberName}`;
            this.bookings.set(key, booking);
          });
        }

        // Load activities
        if (data.activities) {
          this.activities = data.activities.map((activity: any) => ({
            ...activity,
            createdAt: new Date(activity.createdAt)
          }));
        }

        console.log(`Loaded ${this.bookings.size} bookings and ${this.activities.length} activities from disk`);
      }
    } catch (error) {
      console.error('Error loading data from file:', error);
      // Continue with empty data
    }
  }

  private saveData(): void {
    try {
      const data = {
        bookings: Array.from(this.bookings.values()),
        activities: this.activities,
        lastUpdated: new Date().toISOString()
      };
      writeFileSync(this.dataFile, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error('Error saving data to file:', error);
    }
  }

  async getBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }

  async getBookingsByDate(date: string): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(booking => booking.date === date);
  }

  async getBookingsByMember(memberName: string): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(booking => booking.memberName === memberName);
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = randomUUID();
    const booking: Booking = {
      ...insertBooking,
      id,
      deviceInfo: insertBooking.deviceInfo ?? null,
      createdAt: new Date(),
    };

    const key = `${booking.date}-${booking.memberName}`;
    this.bookings.set(key, booking);
    this.saveData();
    return booking;
  }

  async deleteBooking(date: string, memberName: string): Promise<boolean> {
    const key = `${date}-${memberName}`;
    const deleted = this.bookings.delete(key);
    if (deleted) {
      this.saveData();
    }
    return deleted;
  }

  async getRecentActivities(limit: number = 20): Promise<Activity[]> {
    return this.activities
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = randomUUID();
    const activity: Activity = {
      ...insertActivity,
      id,
      deviceInfo: insertActivity.deviceInfo ?? null,
      createdAt: new Date(),
    };

    this.activities.push(activity);
    this.saveData();
    return activity;
  }

  async getMonthlyStats(year: number, month: number): Promise<{ [memberName: string]: number }> {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);

    const monthBookings = Array.from(this.bookings.values()).filter(booking => {
      const bookingDate = new Date(booking.date);
      return bookingDate >= startDate && bookingDate <= endDate;
    });

    const stats: { [memberName: string]: number } = {};
    monthBookings.forEach(booking => {
      stats[booking.memberName] = (stats[booking.memberName] || 0) + 1;
    });

    return stats;
  }

  // Implement trim method in FileStorage
  async trimOldData(): Promise<{ trimmedBookings: number; trimmedActivities: number }> {
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);

    const oldBookingCount = this.bookings.size;
    const oldActivityCount = this.activities.length;

    // Remove old bookings
    for (const [key, booking] of this.bookings.entries()) {
      const bookingDate = new Date(booking.date);
      if (bookingDate < threeMonthsAgo) {
        this.bookings.delete(key);
      }
    }

    // Remove old activities
    this.activities = this.activities.filter(activity => {
      return activity.createdAt >= threeMonthsAgo;
    });

    this.saveData(); // Save changes after trimming

    const trimmedBookings = oldBookingCount - this.bookings.size;
    const trimmedActivities = oldActivityCount - this.activities.length;

    return { trimmedBookings, trimmedActivities };
  }
}

// Switch to persistent file storage to prevent data loss on server restart
export const storage = new FileStorage();